# IndustrialConnect — Part 1

World-class minimalist animated React + Tailwind landing page for the IndustrialConnect manufacturing procurement marketplace.

## Run locally

1. Install Node.js 18+.
2. In this folder:
   npm install
   npm run dev
3. Open the local Vite URL.

## Build
npm run build

This Part 1 is intentionally frontend-only. It contains no real authentication, RFQ database, payments, supplier verification, or production backend yet.
