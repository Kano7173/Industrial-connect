import { Factory } from "lucide-react";

export default function Logo({ light = false }) {
  return (
    <div className={`flex items-center gap-2.5 ${light ? "text-white" : "text-slate-950"}`}>
      <div className="grid h-9 w-9 place-items-center rounded-xl bg-teal-500 text-white shadow-sm">
        <Factory size={19} strokeWidth={2.2} />
      </div>
      <div className="leading-none">
        <div className="text-[15px] font-extrabold tracking-tight">IndustrialConnect</div>
        <div className={`mt-1 text-[9px] font-semibold uppercase tracking-[0.18em] ${light ? "text-slate-400" : "text-slate-400"}`}>
          India manufacturing
        </div>
      </div>
    </div>
  );
}