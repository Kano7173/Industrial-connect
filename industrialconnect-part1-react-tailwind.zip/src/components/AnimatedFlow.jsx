import { motion } from "framer-motion";
import { ArrowRight, Check, Factory, FileText, PackageCheck, Search, ShieldCheck } from "lucide-react";

const nodes = [
  { label: "Requirement", icon: FileText },
  { label: "Matching", icon: Search },
  { label: "Verified suppliers", icon: ShieldCheck },
  { label: "Production", icon: Factory },
  { label: "Delivery", icon: PackageCheck },
];

export default function AnimatedFlow() {
  return (
    <div className="relative mx-auto max-w-6xl">
      <div className="absolute left-10 right-10 top-1/2 hidden h-px bg-slate-200 lg:block" />
      <motion.div
        className="absolute left-10 top-1/2 hidden h-px bg-teal-400 lg:block"
        initial={{ width: 0 }}
        whileInView={{ width: "calc(100% - 80px)" }}
        viewport={{ once: true }}
        transition={{ duration: 1.6, ease: "easeInOut" }}
      />
      <div className="relative grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {nodes.map(([label, Icon], i) => null)}
        {nodes.map((node, i) => {
          const Icon = node.icon;
          return (
            <motion.div
              key={node.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: i * 0.12, duration: 0.5 }}
              className="group rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition hover:-translate-y-1 hover:shadow-soft"
            >
              <div className="mb-4 flex items-center justify-between">
                <div className={`grid h-11 w-11 place-items-center rounded-xl ${i === 0 ? "bg-slate-950 text-white" : "bg-teal-50 text-teal-600"}`}>
                  {i === 0 ? <Check size={20} /> : <Icon size={20} />}
                </div>
                <span className="text-xs font-bold text-slate-300">0{i + 1}</span>
              </div>
              <div className="text-sm font-bold text-slate-900">{node.label}</div>
              <div className="mt-1 text-xs leading-5 text-slate-500">
                {i === 0 ? "Your part requirement" :
                 i === 1 ? "Capability-based selection" :
                 i === 2 ? "Business & capability checks" :
                 i === 3 ? "Production visibility" : "Dispatch & acceptance"}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}