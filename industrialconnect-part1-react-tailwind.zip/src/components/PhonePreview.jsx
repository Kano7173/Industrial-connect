import { motion } from "framer-motion";
import { Check, ChevronRight, CircleDot, PackageCheck, ShieldCheck, Sparkles } from "lucide-react";

export default function PhonePreview() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30, rotate: 1 }}
      animate={{ opacity: 1, y: 0, rotate: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="relative mx-auto w-full max-w-[330px]"
    >
      <div className="absolute -inset-5 rounded-[3rem] bg-teal-100/60 blur-3xl" />
      <div className="relative rounded-[2.5rem] border-[7px] border-slate-950 bg-slate-950 p-2 shadow-2xl">
        <div className="overflow-hidden rounded-[2rem] bg-slate-50">
          <div className="mx-auto mt-2 h-5 w-24 rounded-full bg-slate-950" />
          <div className="p-5 pt-7">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[10px] font-semibold text-slate-400">GOOD MORNING</div>
                <div className="mt-1 text-lg font-extrabold tracking-tight">Find a manufacturer.</div>
              </div>
              <div className="grid h-9 w-9 place-items-center rounded-full bg-teal-500 text-white">
                <Sparkles size={16} />
              </div>
            </div>

            <div className="mt-5 rounded-2xl bg-slate-950 p-4 text-white">
              <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">Active order</div>
              <div className="mt-2 text-sm font-bold">500 × CNC components</div>
              <div className="mt-1 text-xs text-slate-400">SS304 · Delivery in 12 days</div>
              <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/10">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: "62%" }}
                  transition={{ delay: 0.7, duration: 1.1 }}
                  className="h-full rounded-full bg-teal-400"
                />
              </div>
              <div className="mt-2 text-[10px] font-semibold text-teal-300">Production 62%</div>
            </div>

            <div className="mt-4 text-xs font-bold text-slate-500">YOUR WORKFLOW</div>
            <div className="mt-2 space-y-2">
              {[
                ["Requirement submitted", true],
                ["3 manufacturers matched", true],
                ["Quotes received", true],
                ["Select supplier", false]
              ].map(([text, done]) => (
                <div key={text} className="flex items-center gap-3 rounded-xl bg-white p-3 shadow-sm">
                  <div className={`grid h-7 w-7 place-items-center rounded-full ${done ? "bg-teal-50 text-teal-600" : "bg-slate-100 text-slate-400"}`}>
                    {done ? <Check size={14} /> : <CircleDot size={14} />}
                  </div>
                  <div className="flex-1 text-xs font-semibold text-slate-700">{text}</div>
                  <ChevronRight size={14} className="text-slate-300" />
                </div>
              ))}
            </div>

            <div className="mt-4 flex items-center gap-2 rounded-xl border border-teal-100 bg-teal-50 p-3">
              <ShieldCheck size={17} className="text-teal-600" />
              <div className="text-[10px] font-semibold leading-4 text-teal-800">
                Verified suppliers. One transaction workspace.
              </div>
            </div>
          </div>
          <div className="h-4" />
        </div>
      </div>
    </motion.div>
  );
}