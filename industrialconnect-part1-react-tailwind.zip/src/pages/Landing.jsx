import { motion } from "framer-motion";
import { ArrowRight, Check, ChevronRight, Clock3, FileUp, Menu, ShieldCheck, Sparkles, X } from "lucide-react";
import { useState } from "react";
import Logo from "../components/Logo";
import AnimatedFlow from "../components/AnimatedFlow";
import PhonePreview from "../components/PhonePreview";
import { processes, steps, suppliers } from "../lib/data";

export default function Landing() {
  const [menu, setMenu] = useState(false);

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMenu(false);
  };

  return (
    <div className="min-h-screen bg-white text-slate-950">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-slate-200/70 bg-white/90 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 lg:px-8">
          <Logo />
          <nav className="hidden items-center gap-7 md:flex">
            <button onClick={() => scrollTo("how")} className="text-sm font-semibold text-slate-600 hover:text-slate-950">How it works</button>
            <button onClick={() => scrollTo("processes")} className="text-sm font-semibold text-slate-600 hover:text-slate-950">Capabilities</button>
            <button onClick={() => scrollTo("trust")} className="text-sm font-semibold text-slate-600 hover:text-slate-950">Why us</button>
          </nav>
          <div className="hidden items-center gap-3 md:flex">
            <button className="rounded-xl px-4 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-100">Sign in</button>
            <button onClick={() => scrollTo("post")} className="rounded-xl bg-slate-950 px-4 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-slate-800">
              Post requirement
            </button>
          </div>
          <button onClick={() => setMenu(!menu)} className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 md:hidden" aria-label="Open menu">
            {menu ? <X size={19} /> : <Menu size={19} />}
          </button>
        </div>
        {menu && (
          <div className="border-t border-slate-100 bg-white px-5 py-4 md:hidden">
            <div className="grid gap-2">
              <button onClick={() => scrollTo("how")} className="rounded-xl p-3 text-left text-sm font-semibold">How it works</button>
              <button onClick={() => scrollTo("processes")} className="rounded-xl p-3 text-left text-sm font-semibold">Capabilities</button>
              <button onClick={() => scrollTo("trust")} className="rounded-xl p-3 text-left text-sm font-semibold">Why us</button>
              <button onClick={() => scrollTo("post")} className="mt-1 rounded-xl bg-slate-950 p-3 text-sm font-bold text-white">Post requirement</button>
            </div>
          </div>
        )}
      </header>

      <main>
        <section className="relative overflow-hidden bg-slate-50 pt-28">
          <div className="absolute -right-32 top-10 h-80 w-80 rounded-full bg-teal-100/50 blur-3xl" />
          <div className="absolute -left-40 bottom-0 h-96 w-96 rounded-full bg-slate-200/60 blur-3xl" />
          <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 pb-20 lg:grid-cols-[1.05fr_.95fr] lg:px-8 lg:pb-28">
            <div>
              <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-600 shadow-sm">
                <span className="h-1.5 w-1.5 rounded-full bg-teal-500" />
                Industrial procurement, simplified
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: .08, duration: .7 }}
                className="mt-6 max-w-3xl text-5xl font-black tracking-[-0.045em] text-slate-950 sm:text-6xl lg:text-[72px] lg:leading-[.98]"
              >
                Manufacturing,
                <span className="block text-slate-400">without the headache.</span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: .16, duration: .7 }}
                className="mt-6 max-w-xl text-base leading-7 text-slate-600 sm:text-lg"
              >
                Upload your drawing. Get competitive quotes from verified Indian manufacturers. Track production, quality and delivery in one simple workspace.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: .24, duration: .7 }}
                className="mt-8 flex flex-col gap-3 sm:flex-row"
              >
                <button onClick={() => scrollTo("post")} className="group inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-950 px-6 py-4 text-sm font-extrabold text-white shadow-xl shadow-slate-950/10 transition hover:-translate-y-0.5 hover:bg-slate-800">
                  Post a requirement
                  <ArrowRight size={17} className="transition group-hover:translate-x-1" />
                </button>
                <button onClick={() => scrollTo("how")} className="inline-flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-white px-6 py-4 text-sm font-extrabold text-slate-700 transition hover:bg-slate-50">
                  See how it works
                </button>
              </motion.div>

              <div className="mt-8 flex flex-wrap gap-x-5 gap-y-3 text-xs font-semibold text-slate-500">
                {["Verified manufacturers", "Competitive quotes", "Production visibility"].map((x) => (
                  <div key={x} className="flex items-center gap-2">
                    <span className="grid h-5 w-5 place-items-center rounded-full bg-teal-50 text-teal-600"><Check size={12} /></span>{x}
                  </div>
                ))}
              </div>
            </div>
            <PhonePreview />
          </div>
        </section>

        <section id="trust" className="border-y border-slate-100 bg-white">
          <div className="mx-auto grid max-w-7xl gap-8 px-5 py-8 sm:grid-cols-3 lg:px-8">
            {[
              [ShieldCheck, "Verified network", "Business and capability checks designed for industrial procurement."],
              [Sparkles, "Smart matching", "Match requirements to relevant manufacturing capabilities."],
              [Clock3, "Clear progress", "One order room for production, quality, shipment and acceptance."]
            ].map(([Icon, title, text]) => (
              <div key={title} className="flex gap-4">
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-slate-100 text-slate-700"><Icon size={19} /></div>
                <div><div className="text-sm font-extrabold">{title}</div><div className="mt-1 text-xs leading-5 text-slate-500">{text}</div></div>
              </div>
            ))}
          </div>
        </section>

        <section id="how" className="px-5 py-20 lg:px-8 lg:py-28">
          <div className="mx-auto max-w-7xl">
            <div className="max-w-2xl">
              <div className="text-xs font-extrabold uppercase tracking-[.18em] text-teal-600">One simple workflow</div>
              <h2 className="mt-3 text-4xl font-black tracking-[-.035em] sm:text-5xl">From drawing to delivery.</h2>
              <p className="mt-4 text-base leading-7 text-slate-500">The platform hides procurement complexity so your team can focus on making decisions, not chasing suppliers.</p>
            </div>
            <div className="mt-10"><AnimatedFlow /></div>
          </div>
        </section>

        <section id="post" className="bg-slate-950 px-5 py-20 text-white lg:px-8 lg:py-24">
          <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[1fr_.8fr] lg:items-center">
            <div>
              <div className="text-xs font-extrabold uppercase tracking-[.18em] text-teal-300">Start with one requirement</div>
              <h2 className="mt-3 max-w-2xl text-4xl font-black tracking-[-.035em] sm:text-5xl">Tell us what you need made.</h2>
              <p className="mt-4 max-w-xl leading-7 text-slate-400">A focused RFQ experience designed to get the important information without overwhelming the buyer.</p>
              <button className="mt-8 inline-flex items-center gap-2 rounded-2xl bg-white px-6 py-4 text-sm font-extrabold text-slate-950 transition hover:bg-teal-50">
                Start your RFQ <ArrowRight size={17} />
              </button>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/[.05] p-5 shadow-glow">
              <div className="text-xs font-bold text-slate-400">WHAT ARE YOU MANUFACTURING?</div>
              <div className="mt-4 grid grid-cols-2 gap-3">
                {processes.slice(0, 4).map((p, i) => (
                  <button key={p.name} className="group rounded-2xl border border-white/10 bg-white/[.05] p-4 text-left transition hover:-translate-y-0.5 hover:border-teal-400/40 hover:bg-white/[.08]">
                    <div className="text-xl">{p.icon}</div>
                    <div className="mt-3 text-xs font-extrabold">{p.name}</div>
                    <div className="mt-1 text-[10px] leading-4 text-slate-500">{p.description}</div>
                  </button>
                ))}
              </div>
              <div className="mt-4 flex items-center gap-3 rounded-2xl border border-dashed border-white/15 p-4">
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-white/10"><FileUp size={17} /></div>
                <div className="flex-1"><div className="text-xs font-bold">Upload drawing/specification</div><div className="mt-1 text-[10px] text-slate-500">PDF, DWG, STEP or image</div></div>
                <ChevronRight size={16} className="text-slate-500" />
              </div>
            </div>
          </div>
        </section>

        <section id="processes" className="px-5 py-20 lg:px-8 lg:py-28">
          <div className="mx-auto max-w-7xl">
            <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
              <div>
                <div className="text-xs font-extrabold uppercase tracking-[.18em] text-teal-600">Capabilities</div>
                <h2 className="mt-3 text-4xl font-black tracking-[-.035em]">Built around real manufacturing.</h2>
              </div>
              <div className="max-w-sm text-sm leading-6 text-slate-500">Start narrow. Build trust. Expand into more processes as the network grows.</div>
            </div>
            <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {processes.map((p, i) => (
                <motion.div key={p.name} initial={{ opacity: 0, y: 15 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * .05 }} className="group rounded-3xl border border-slate-200 p-6 transition hover:-translate-y-1 hover:border-slate-300 hover:shadow-soft">
                  <div className="flex items-start justify-between">
                    <div className="grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-xl">{p.icon}</div>
                    <ArrowRight size={17} className="text-slate-300 transition group-hover:translate-x-1 group-hover:text-slate-700" />
                  </div>
                  <h3 className="mt-7 text-lg font-extrabold">{p.name}</h3>
                  <p className="mt-2 text-sm leading-6 text-slate-500">{p.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-slate-50 px-5 py-20 lg:px-8 lg:py-28">
          <div className="mx-auto max-w-7xl">
            <div className="max-w-2xl">
              <div className="text-xs font-extrabold uppercase tracking-[.18em] text-teal-600">Designed for trust</div>
              <h2 className="mt-3 text-4xl font-black tracking-[-.035em] sm:text-5xl">Know who is making your part.</h2>
              <p className="mt-4 text-base leading-7 text-slate-500">Company identity stays visible. Verification, performance and transaction history make supplier selection more informed.</p>
            </div>
            <div className="mt-10 grid gap-4 lg:grid-cols-3">
              {suppliers.map((s, i) => (
                <div key={s.name} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div className="grid h-11 w-11 place-items-center rounded-xl bg-slate-950 text-white font-black">{s.name[0]}</div>
                    <span className="inline-flex items-center gap-1 rounded-full bg-teal-50 px-2.5 py-1 text-[10px] font-extrabold text-teal-700"><ShieldCheck size={12} /> Verified</span>
                  </div>
                  <h3 className="mt-5 text-base font-extrabold">{s.name}</h3>
                  <div className="mt-1 text-xs text-slate-500">{s.location}</div>
                  <div className="mt-5 grid grid-cols-3 gap-2 border-y border-slate-100 py-4">
                    <div><div className="text-[10px] text-slate-400">Process</div><div className="mt-1 text-xs font-bold">{s.process}</div></div>
                    <div><div className="text-[10px] text-slate-400">Quality</div><div className="mt-1 text-xs font-bold">★ {s.score}</div></div>
                    <div><div className="text-[10px] text-slate-400">On-time</div><div className="mt-1 text-xs font-bold">{s.onTime}</div></div>
                  </div>
                  <button className="mt-4 flex w-full items-center justify-between rounded-xl bg-slate-50 px-4 py-3 text-xs font-extrabold transition hover:bg-slate-100">
                    View manufacturer <ArrowRight size={14} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="px-5 py-20 lg:px-8 lg:py-28">
          <div className="mx-auto max-w-7xl rounded-[2rem] bg-teal-500 px-6 py-12 text-white sm:px-10 lg:px-14">
            <div className="grid gap-8 lg:grid-cols-[1fr_auto] lg:items-center">
              <div>
                <div className="text-xs font-extrabold uppercase tracking-[.18em] text-teal-100">For manufacturers</div>
                <h2 className="mt-3 max-w-2xl text-3xl font-black tracking-[-.03em] sm:text-4xl">Receive relevant RFQs. Quote with confidence.</h2>
                <p className="mt-3 max-w-xl leading-7 text-teal-50">Build a capability profile, receive matched opportunities and manage production from the same platform.</p>
              </div>
              <button className="inline-flex items-center justify-center gap-2 rounded-2xl bg-white px-6 py-4 text-sm font-extrabold text-slate-950 transition hover:bg-teal-50">Join as manufacturer <ArrowRight size={17} /></button>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-100 bg-white px-5 py-8 lg:px-8">
        <div className="mx-auto flex max-w-7xl flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
          <Logo />
          <div className="text-xs text-slate-400">© 2026 IndustrialConnect. Built for Indian manufacturing.</div>
        </div>
      </footer>
    </div>
  );
}